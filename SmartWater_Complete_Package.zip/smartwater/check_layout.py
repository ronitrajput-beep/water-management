import fitz,json,re
from pathlib import Path
from docx import Document
from PIL import Image,ImageOps,ImageDraw
R=Path(__file__).parent
D=fitz.open(R/'SmartWater_Report.pdf')
def norm(t):return re.sub(r'\s+',' ',t).strip()
keys=[p.text for p in Document(R/'SmartWater_Report.docx').paragraphs if p.style.name=='Heading 1']
keys+=['Fig. 3.1','Fig. 3.2','Fig. 4.1','Fig. 4.2','Table F.1','Table 2.1','Table 3.1','Table 3.2','Table 3.3','Table 4.1','Table 4.2','Table 5.1','Table A.I','Table A.II','Table A.IV','Table A.VII']
mp={}
for k in keys:
 needle=k+':' if k.startswith(('Table','Fig.')) and k!='Table of Contents' else k
 for p in D:
  if norm(needle) in norm(p.get_text()) and not ('Report contents' in p.get_text() and k!='Table of Contents'):
   foot=[b[4].strip() for b in p.get_text('blocks') if b[1]>p.rect.height-70]
   mp[k]=' '.join(foot)
print(json.dumps(mp,indent=2));(R/'page_map.json').write_text(json.dumps(mp,indent=2))
for name in ['SmartWater_Report','SmartWater_Presentation']:
 d=fitz.open(R/(name+'.pdf'));thumbs=[]
 for i,p in enumerate(d):
  pix=p.get_pixmap(matrix=fitz.Matrix(.4,.4));im=Image.frombytes('RGB',[pix.width,pix.height],pix.samples);im.thumbnail((320,270));tile=Image.new('RGB',(340,300),'#dddddd');tile.paste(im,((340-im.width)//2,20));ImageDraw.Draw(tile).text((10,282),str(i+1),fill='black');thumbs.append(tile)
 cols=4;rows=(len(thumbs)+cols-1)//cols;sheet=Image.new('RGB',(cols*340,rows*300),'white')
 for i,im in enumerate(thumbs):sheet.paste(im,((i%cols)*340,(i//cols)*300))
 sheet.save(R/(name+'_contact.png'))
