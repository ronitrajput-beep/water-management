from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE
from pathlib import Path
import json
R=Path(__file__).parent
prs=Presentation();prs.slide_width=Inches(13.333);prs.slide_height=Inches(7.5)
NAVY='123348';TEAL='087E8B';WHITE='F7FAFC';GRAY='506578';GOLD='D48A36';LIGHT='E8F1F4'
def box(s,x,y,w,h,color):
 sh=s.shapes.add_shape(MSO_SHAPE.RECTANGLE,Inches(x),Inches(y),Inches(w),Inches(h));sh.fill.solid();sh.fill.fore_color.rgb=RGBColor.from_string(color);sh.line.fill.background();return sh
def text(s,x,y,w,h,txt,size=22,color=NAVY,bold=False):
 sh=s.shapes.add_textbox(Inches(x),Inches(y),Inches(w),Inches(h));tf=sh.text_frame;tf.word_wrap=True
 for i,line in enumerate(txt.split('\n')):
  p=tf.paragraphs[0] if i==0 else tf.add_paragraph();p.text=line;p.font.name='Aptos';p.font.size=Pt(size);p.font.bold=bold;p.font.color.rgb=RGBColor.from_string(color);p.space_after=Pt(12)
 return sh
def slide(title,kicker='SMARTWATER / DESIGN EXPERIENCE',note='',dark=False):
 s=prs.slides.add_slide(prs.slide_layouts[6]);s.background.fill.solid();s.background.fill.fore_color.rgb=RGBColor.from_string(NAVY if dark else WHITE)
 text(s,.55,.25,12,.35,kicker,11, '69D1D7' if dark else TEAL,True)
 text(s,.55,.85,12.2,1.1,title,32,'FFFFFF' if dark else NAVY,True)
 box(s,.55,6.95,12.2,.015,TEAL)
 text(s,.55,7.05,11,.25,'Ronit Rajput • E052 • B.Tech. CSBS, Semester V • MPSTME',10,'BCD0DC' if dark else GRAY)
 text(s,12,7.02,.8,.3,f'{len(prs.slides):02d}',11,'FFFFFF' if dark else GRAY)
 if note:s.notes_slide.notes_text_frame.text=note
 return s
def cards(s,items):
 w=(12.2-.25*(len(items)-1))/len(items)
 for i,(head,body) in enumerate(items):
  x=.55+i*(w+.25);box(s,x,2.1,w,4.35,LIGHT);box(s,x,2.1,w,.08,TEAL);text(s,x+.2,2.35,w-.4,.8,head,22,TEAL,True);text(s,x+.2,3.25,w-.4,3.05,body,19)
def image(s,name,x=.8,y=2,w=11.7,h=None):
 kw={'width':Inches(w)}
 if h:kw={'height':Inches(h)}
 s.shapes.add_picture(str(R/'figures'/name),Inches(x),Inches(y),**kw)
s=slide('SMARTWATER',note='Introduce this as an initial literature-led proposal and an AI-assisted, executed synthetic prototype. Do not describe it as months of completed fieldwork.',dark=True)
text(s,.65,2,11.5,1.4,'Explainable leak detection\nand demand monitoring',34,'FFFFFF',True)
text(s,.65,3.7,11.5,.8,'Five research studies → a coding-focused project → an 18-month plan',23,'69D1D7')
text(s,.65,5.05,11.5,1.2,'Ronit Rajput | E052\nMentor: Dr Poulami Das Ray\nMPSTME • Academic Year 2026–27',20,'FFFFFF')
s=slide('The problem is interpretation, not just measurement',note='Explain that no unsupported global water-loss number is needed. The problem is distinguishing causes of unusual observations.')
cards(s,[('Flow rises','Could be a leak, legitimate demand or an incorrect reading.'),('Pressure falls','Could be leakage, a demand surge or an operational change.'),('Data disappear','Missing telemetry must remain visible; it is not normal operation.')])
s=slide('A focused, testable project question',note='The question is conditional. We want to know both when corroboration helps and when it sacrifices sensitivity.')
text(s,.8,2.2,11.6,1.6,'When does pressure corroboration reduce false water-leak alerts, and what sensitivity does it sacrifice?',32,NAVY,True)
text(s,.8,4.25,11.6,1.7,'Proposed users: facilities operator and maintenance technician\nCurrent scope: Python software + synthetic evaluation\nNext scope: public benchmarks, hydraulic scenarios and an approved pilot',23)
s=slide('Five studies, five design lessons',note='These are real studies. The review was prepared from accessible author repositories and benchmark documentation. Full publisher PDFs were unavailable and must be checked before final academic submission. Limitations are project-specific interpretations.')
rows=[('LeakDB [1]','Repeatable scenarios and evaluation'),('BattLeDIM [2]','Flow–pressure evidence and localization'),('BATADAL [3]','Telemetry can be misleading or manipulated'),('LeakG3PD [4]','Scenario realism affects conclusions'),('BWDF [5]','Demand context and temporal validation')]
for i,(a,b) in enumerate(rows):
 y=2+i*.78;box(s,.65,y,12,.62,LIGHT);text(s,.85,y+.05,3.1,.5,a,21,TEAL,True);text(s,4,y+.05,8.3,.5,b,21)
s=slide('01 / LeakDB: make evaluation reproducible',kicker='LITERATURE REVIEW / VRACHIMIS ET AL., 2018 [1]',note='The author repository confirms a synthetic leakage dataset and MATLAB evaluation example. The catalog describes Net1 and Hanoi scenarios. Do not say the current toy generator reproduces LeakDB.')
cards(s,[('Contribution','Synthetic leak scenarios, labels and common evaluation.'),('Transfer limitation','Simulation assumptions and rich measurements may not match a small deployment.'),('Our response','Python data adapter, scenario-level splits and event metrics. Adapter is planned.')])
s=slide('02 / BattLeDIM: detection is not localization',kicker='LITERATURE REVIEW / VRACHIMIS ET AL. [2]',note='The benchmark uses L-Town, SCADA data and model uncertainty. The prototype has no spatial graph, so it cannot identify an exact leaking pipe.')
cards(s,[('Contribution','Shared leakage detection and isolation challenge using flow and pressure.'),('Transfer limitation','Location inference depends on spatial evidence and sensor coverage.'),('Our response','Explain zone-level evidence first; add uncertainty-aware localization later.')])
s=slide('03 / BATADAL: check the trustworthiness of data',kicker='LITERATURE REVIEW / TAORMINA ET AL., 2018 [3]',note='Attack detection and physical leak detection are different label spaces. A suspicious value is not proof of a cyberattack. Current code handles finite-value checks only.')
cards(s,[('Contribution','Cyber-physical attack detection from simulated water-system telemetry.'),('Transfer limitation','An anomaly may be an attack, fault or physical event; cause remains ambiguous.'),('Our response','Separate missing data, suspicious telemetry and possible hydraulic events.')])
s=slide('04 / LeakG3PD: improve scenario realism',kicker='LITERATURE REVIEW / PILOTTO FIGUEIREDO ET AL., 2025 [4]',note='The original repository describes pressure-dependent leak demand, additional Net3 scenarios, pipe-interior leak placement and demand variability. The toy demonstration is not a hydraulic simulator.')
cards(s,[('Contribution','Python generator with pressure-dependent leakage and varied scenarios.'),('Transfer limitation','More realistic simulation still needs cross-network and field checks.'),('Our response','Scenario manifests, hydraulic modelling and controlled noise/missingness tests.')])
s=slide('05 / BWDF: establish what normal demand looks like',kicker='LITERATURE REVIEW / ALVISI ET AL., 2025 [5]',note='The competition studies real DMA demand forecasting. The supplied code only uses a training-derived hourly median. No competition data or scores are reproduced.')
cards(s,[('Contribution','Real DMA forecasting task with a shared evaluation workflow.'),('Transfer limitation','A forecast error does not establish a leak; demand can change legitimately.'),('Our response','Seasonal baseline plus physical corroboration; separate forecast and alert metrics.')])
s=slide('The proposed contribution is an integrated workflow',note='This is a project integration opportunity, not an established novelty claim. Current and future capabilities are distinguished in the diagram.')
image(s,'architecture.png',2,2,9.3)
s=slide('Start with a transparent baseline',note='The score matrix is a design judgment, not an experimental ranking. A complex model can be added if representative evidence justifies it.')
cards(s,[('Why this design','Hourly median baseline\nInspectable rules\nLow data requirement\nEasy reproduction'),('Detection logic','Excess flow > 3 L/min\nPressure drop > 0.8 m\nTwo consecutive samples\nMissing input resets count'),('Explicit trade-off','Pressure evidence can reduce false alerts while missing weak-signature leaks.')])
s=slide('The implemented Python prototype',note='These outputs were generated and tested during preparation. The HTML page is a static report viewer, not a live server or deployed dashboard.')
text(s,.75,2.1,5.8,4.6,'Implemented\n• Synthetic generator\n• Training-only baseline\n• Two persistent detectors\n• Confusion and event scoring\n• CSV / JSON / SQLite outputs\n• Charts and static HTML viewer',22)
text(s,7,2.1,5.6,4.6,'Not yet implemented\n• Real sensor ingestion\n• Public-benchmark adapter\n• Hydraulic simulation\n• Pipe localization\n• Attack diagnosis\n• Live operator workflow',22,GRAY)
s=slide('Experimental design: 672 hourly samples',note='The data are deliberately constructed. This helps verify software logic but creates a validity limit because pressure corroboration is useful by design.')
cards(s,[('Train: first 14 days','336 clean samples\nHourly median flow\nMedian pressure\nNo future samples used'),('Test: next 14 days','336 samples\n3 injected leak events\n1 high-demand episode\n1 pressure-only disturbance'),('Coverage','4 missing flow readings\n332 scored observations\n96 leak samples\n236 normal samples')])
s=slide('Actual output: synthetic telemetry and alerts',note='Walk through the dashed training boundary, leak intervals and orange alert points. The x-axis is synthetic elapsed time, not a record of project work over calendar days.')
image(s,'results.png',2,2,9.3)
s=slide('Pressure corroboration reduces false alerts here',note='State both the benefit and cost. Flow-only TP=87 FP=5 FN=9 TN=231. Hybrid TP=85 FP=0 FN=11 TN=236. All scores apply only to this synthetic experiment.')
image(s,'comparison.png',.7,2,8.2)
text(s,9.2,2.25,3.5,3.8,'False positives\n5 → 0\n\nRecall\n90.63% → 88.54%\n\nF1\n0.9255 → 0.9392',23,TEAL,True)
s=slide('Findings that matter beyond one F1 score',note='All three events were detected but some event samples were missed. One-hour delay results from the two-sample rule at hourly frequency. The ten-seed range is sensitivity to noise, not independent deployment validation.')
cards(s,[('Event detection','3 of 3 events detected\nOne-hour delay each\nSample recall is lower than event recall.'),('Noise sensitivity','Hybrid F1 across 10 seeds:\n0.8966–0.9508\nSame scenario design; different noise.'),('Availability','98.81% valid test coverage\nFour missing samples remain explicitly reported.')])
s=slide('Six tests passed — specific software properties',note='The report includes the actual test log. These tests verify software properties and scoring, not physical realism.')
items=['Deterministic generation','Training unaffected by future values','Missing values reset persistence','Pressure-only changes are rejected','Flow-only changes need corroboration','Confusion counts and event delay are correct']
for i,item in enumerate(items):
 y=2+i*.65;text(s,.8,y,.7,.45,'✓',24,TEAL,True);text(s,1.5,y,10.7,.5,item,22)
s=slide('Where the current method can fail',note='Mention these before being asked in the viva. A legitimate demand surge can reduce pressure. A real leak may have little measurable pressure change. These cases challenge the exact rule used here.')
cards(s,[('Physical ambiguity','Demand surge + pressure fall may produce a false alert. Weak-pressure leaks may be missed.'),('Evaluation limits','Only three events\nHand-chosen thresholds\nNo hydraulic solver\nNo independent real data'),('Next experiment','Hold out scenarios\nValidate thresholds\nTest missingness and drift\nCompare on public data')])
s=slide('An eighteen-month development pathway',note='The timeline is prospective. Do not describe the first months as already completed. The immediate action is personal reproduction and mentor review.')
image(s,'timeline.png',.6,2.1,12.1)
s=slide('Semester submissions and acceptance gates',note='The first gate is reproducibility, the second is generalization, and the third is operational usefulness under approved conditions.')
cards(s,[('Semester 1','Verified literature\nBaseline software\nOne benchmark adapter\nEvidence register + demo'),('Semester 2','Hydraulic scenarios\nRobustness and ablations\nInterface + testbed\nRevised report'),('Semester 3','Approved pilot or benchmark study\nFailure analysis\nFinal report and viva\nReproducible handover')])
s=slide('Contribution, evidence and disclosure',note='Ronit supplied the topic and project constraints. The draft and prototype were generated with AI assistance and executed during preparation. Personal reproduction, full-text verification and mentor review are pending. Follow institutional policy.')
text(s,.8,2.1,11.7,4.4,'Evidence available now\nSource notes • runnable code • six-test log • synthetic data • metrics • charts\n\nTo be verified by Ronit\nRead the full papers • reproduce the outputs • explain and modify the code\n\nAcademic record\nAI assistance disclosed • no fabricated meetings or fieldwork • signatures pending',23)
s=slide('Conclusion: a reproducible starting point',note='Close with the qualified finding and immediate next step. Do not claim water savings, deployment readiness or a new state-of-the-art algorithm.',dark=True)
text(s,.8,2.25,11.7,1.6,'Combine demand context, pressure evidence\nand data-quality awareness.',32,'FFFFFF',True)
text(s,.8,4.2,11.7,1.8,'The prototype demonstrates an inspectable false-alarm / recall trade-off.\nNext: verify sources, reproduce the code and evaluate a public benchmark.',24,'69D1D7')
s=slide('Research references',note='These identifiers match the report. Publication metadata requiring verification is marked there. The additional WaterBenchmarkHub source documents accessible descriptions; full-text PDFs were not retrieved.')
refs=[('[1] LeakDB — Vrachimis et al., 2018','10.5281/zenodo.1313116 (research artifact)'),('[2] BattLeDIM — Vrachimis et al.','10.1061/(ASCE)WR.1943-5452.0001601'),('[3] BATADAL — Taormina et al., 2018','10.1061/(ASCE)WR.1943-5452.0000969'),('[4] LeakG3PD — Pilotto Figueiredo et al., 2025','10.1007/978-3-031-77738-7_7'),('[5] BWDF — Alvisi et al., 2025','10.1061/JWRMD5.WRENG-6887')]
for i,(a,b) in enumerate(refs):
 y=1.95+i*.84;text(s,.75,y,11.8,.35,a,18,NAVY,True);text(s,.75,y+.36,11.8,.3,b,15,GRAY)
text(s,.75,6.3,11.8,.5,'Supporting catalog: github.com/WaterFutures/WaterBenchmarkHub [6]',14,TEAL)
prs.save(R/'SmartWater_Presentation.pptx');print('Saved',len(prs.slides),'slides')
