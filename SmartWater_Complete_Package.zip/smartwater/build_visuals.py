from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
R=Path(__file__).parent
fig,ax=plt.subplots(figsize=(10,5));ax.set_xlim(0,10);ax.set_ylim(0,5);ax.axis('off')
boxes=[(.2,3.3,'Acquire / generate\nToy generator now\nSensors / benchmark later'),(3.7,3.3,'Validate and fit\nFinite-value checks\nTraining-only hourly median'),(7.2,3.3,'Detect\nFlow + pressure\nTwo-sample persistence'),(7.2,.7,'Evaluate\nConfusion counts\nEvents and delay'),(3.7,.7,'Store\nCSV · JSON · SQLite\nExperiment evidence'),(.2,.7,'Present\nCharts + static HTML\nOperator workflow later')]
for x,y,txt in boxes:
 ax.add_patch(FancyBboxPatch((x,y),2.6,1.2,boxstyle='round,pad=.1',facecolor='#e8f5f3',edgecolor='#147c87'));ax.text(x+1.3,y+.6,txt,ha='center',va='center',fontsize=10)
for a,b in [((2.9,3.9),(3.5,3.9)),((6.4,3.9),(7,3.9)),((8.5,3.2),(8.5,2.1)),((7.1,1.3),(6.5,1.3)),((3.6,1.3),(3,1.3))]:ax.annotate('',xy=b,xytext=a,arrowprops={'arrowstyle':'->','color':'#183449','lw':2})
fig.tight_layout();fig.savefig(R/'figures/architecture.png',dpi=180);plt.close(fig)
fig,ax=plt.subplots(figsize=(10,3.8))
labels=['Sources and requirements','Public-data adapter','Semester I review','Hydraulic / robust evaluation','Interface and testbed','Supervised pilot','Final evaluation / handover']
starts=[1,3,5,7,10,13,16];dur=[2,2,2,3,3,3,3]
for i,(s,d) in enumerate(zip(starts,dur)):ax.barh(i,d,left=s-.5,color=['#147c87','#1d526a','#d29139'][min(s//7,2)])
ax.set_yticks(range(7),labels);ax.invert_yaxis();ax.set_xticks(range(1,19));ax.set_xlim(.5,18.5);ax.set_xlabel('Prospective month');ax.grid(axis='x',alpha=.2);fig.tight_layout();fig.savefig(R/'figures/timeline.png',dpi=180);plt.close(fig)
