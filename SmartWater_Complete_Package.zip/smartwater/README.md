# SmartWater submission package

Prepared for Ronit Rajput, E052, B.Tech. CSBS, Semester V, MPSTME.
Mentor: Dr Poulami Das Ray.

## Files
- SmartWater_Report.docx: editable report using the supplied institutional structure.
- SmartWater_Report.pdf: rendered report; Times New Roman is specified in DOCX but the available PDF renderer substitutes Liberation Serif.
- SmartWater_Presentation.pptx: 23 editable slides with presenter notes, suitable for importing into Canva. Canva itself was unavailable, so import fidelity has not been tested.
- SmartWater_Presentation.pdf: presentation preview.
- code/: complete Python implementation, six unit tests and pinned dependency versions.
- results/: actual synthetic CSV, JSON metrics, SQLite database, test log and static HTML dashboard.
- figures/: generated architecture, schedule and result graphs.
- sources/: inspected research documentation. These are source notes, not downloaded full papers.

## Run the implementation
From the extracted smartwater folder:

    python -m venv .venv
    . .venv/bin/activate
    python -m pip install -r code/requirements.txt
    python code/smartwater.py
    python -m unittest discover -s code -v

Open results/dashboard.html locally to inspect the generated graphs and metrics.
No server or sensor connection is required. Re-running replaces the demonstration output files.

## Actual execution results
Six tests passed. Seed-42 hybrid detector: TP=85, FP=0, FN=11, TN=236;
precision=1.0000, recall=0.8854, F1=0.9392. Three events detected with one-hour delay each.
Four invalid test records are excluded from classification metrics and reported separately.
All observations are synthetic. The data represent 28 simulated days, not 28 days of student activity.

## Before submission
1. Reproduce the code personally and understand the trade-off between false alarms and recall.
2. Read the five full papers and confirm bibliographic metadata. Publisher sites were blocked in the preparation environment; author repositories and WaterBenchmarkHub were used. Limitations are explicitly presented as project-specific critical interpretations.
3. Enter SAP ID; confirm Design Experience stage, vertical and institutional details.
4. Obtain mentor review and required signatures. No signatures, meetings or fieldwork were fabricated.
5. Follow institutional AI-use and similarity-check rules. Neither approval nor similarity clearance has been performed here.
6. If Times New Roman is strictly required in the PDF, open the DOCX on a computer with that font installed, check page references and export again.

## Canva import
In Canva, upload/import SmartWater_Presentation.pptx, then review slide layouts and fonts before presenting. Text and shapes are editable; plots are embedded images. Speaker notes are also included in the PowerPoint, but Canva's handling of notes can vary.

## Development boundaries
The prototype does not ingest public benchmark data, solve hydraulic equations, localize pipes, detect cyberattacks, control valves or measure actual water savings. These features are proposed milestones in the eighteen-month plan.
