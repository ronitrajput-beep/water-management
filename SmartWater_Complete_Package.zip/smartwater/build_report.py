from pathlib import Path
import json, datetime
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.section import WD_SECTION_START
ROOT=Path(__file__).parent
M=json.loads((ROOT/'results/metrics.json').read_text())
doc=Document();sec=doc.sections[0]
sec.page_height=Inches(11.69);sec.page_width=Inches(8.27)
sec.left_margin=Inches(1.5);sec.right_margin=sec.top_margin=sec.bottom_margin=Inches(1)
for name in ['Normal','Title','Subtitle','Heading 1','Heading 2','Heading 3','Caption']:
 s=doc.styles[name];s.font.name='Times New Roman';s.font.color.rgb=RGBColor.from_string('000000')
 s.font.size=Pt({'Title':22,'Heading 1':18,'Heading 2':14,'Heading 3':12,'Caption':10}.get(name,12))
 s.paragraph_format.line_spacing=1.5
 s.paragraph_format.space_after=Pt(0)
for name in ['Heading 1','Heading 2','Heading 3']:doc.styles[name].font.bold=True
style=doc.styles['Normal'];style.paragraph_format.alignment=WD_ALIGN_PARAGRAPH.LEFT
header=sec.header.paragraphs[0];header.text='SmartWater: Explainable Water Monitoring\t2026–27';header.style='Caption'
header.paragraph_format.tab_stops.add_tab_stop(Inches(4.7))
sec.different_first_page_header_footer=True

def field(p,code):
 r=p.add_run();a=OxmlElement('w:fldSimple');a.set(qn('w:instr'),code);r._r.addnext(a)
def numbering(section,fmt,start):
 pr=section._sectPr;el=OxmlElement('w:pgNumType');el.set(qn('w:fmt'),fmt);el.set(qn('w:start'),str(start));pr.append(el)
 f=section.footer.paragraphs[0];f.alignment=WD_ALIGN_PARAGRAPH.RIGHT;field(f,'PAGE')
def para(text):
 for p in text.strip().split('\n\n'):doc.add_paragraph(p.strip())
def page(title,text='',level=2):
 h=doc.add_heading(title,level)
 if level==1:h.paragraph_format.page_break_before=True
 para(text)
def table(caption,heads,rows):
 cp=doc.add_paragraph(caption,'Caption');cp.paragraph_format.keep_with_next=True;t=doc.add_table(rows=1, cols=len(heads));t.style='Table Grid'
 for c,v in zip(t.rows[0].cells,heads):c.text=str(v)
 for row in rows:
  for c,v in zip(t.add_row().cells,row):c.text=str(v)
 for row in t.rows:
  for cell in row.cells:
   for p in cell.paragraphs:
    p.paragraph_format.line_spacing=1.15
    for r in p.runs:r.font.size=Pt(10)
def fig(name,caption):
 doc.add_picture(str(ROOT/'figures'/name),width=Inches(5.65));doc.paragraphs[-1].paragraph_format.keep_with_next=True;doc.add_paragraph(caption,'Caption')
# Cover
for txt,style in [('SMARTWATER','Title'),('Explainable Leak Detection and Demand Monitoring for Smart Water Systems','Title'),('Design Experience Project Report','Subtitle'),('Literature Review, Initial Software Proof of Concept and 18-Month Development Proposal','Subtitle')]:
 p=doc.add_paragraph(txt,style);p.alignment=WD_ALIGN_PARAGRAPH.CENTER
para('Submitted in partial fulfilment of the requirements of\nB.Tech. in Computer Science and Business Systems (CSBS)\nSemester V\nDesign Experience stage / vertical: [Confirm with coordinator]')
for txt in ['By Ronit Rajput • Roll No. E052 • SAP ID: [To be entered]','Under the supervision of Dr Poulami Das Ray','Mukesh Patel School of Technology Management & Engineering (MPSTME)','SVKM’s NMIMS (Deemed-to-be University), Mumbai','Academic Year 2026–27']:
 p=doc.add_paragraph(txt);p.alignment=WD_ALIGN_PARAGRAPH.CENTER
page('Certificate — for institutional verification',"""SVKM’s NMIMS (Deemed-to-be University)

Mukesh Patel School of Technology Management & Engineering (MPSTME), Mumbai

This page is an unsigned certificate template. It becomes an institutional certification only after review and signature by the authorized faculty members.

This is to certify that the Design Experience project entitled “SmartWater: Explainable Leak Detection and Demand Monitoring for Smart Water Systems”, submitted by Ronit Rajput (Roll No. E052), is presented for assessment in the B.Tech. Computer Science and Business Systems programme, Semester V, during Academic Year 2026–27.

The scope presented is a literature-led project proposal and an initial, AI-assisted software proof of concept. The mentor should confirm the work personally demonstrated by the student before certification.

Project Mentor: Dr Poulami Das Ray\nSignature: ____________________

Vertical SPOC: ____________________\nSignature: ____________________

Head of Department: ____________________\nSignature: ____________________

Date: ____________________     Place: Mumbai""",1)
front=doc.add_section(WD_SECTION_START.NEW_PAGE);front.different_first_page_header_footer=False;front.footer.is_linked_to_previous=False;numbering(front,'lowerRoman',1)
doc.add_heading('Acknowledgement, Team Details and Declaration',1)
para("""This project proposal is prepared for the Design Experience component of the B.Tech. CSBS programme at MPSTME. Dr Poulami Das Ray is identified as the faculty mentor. Specific guidance, reviews and resource support should be acknowledged after they have actually been received. The researchers and maintainers of the cited open research repositories are acknowledged for making water-system methods and benchmark documentation accessible.

The present report and accompanying software were prepared with AI assistance. Their preparation does not establish that the student has completed a semester of implementation, field experiments or mentor reviews. The student is responsible for checking the sources, understanding the code, reproducing the results and complying with institutional rules on permitted AI use.""")
table('Table F.1: Student details',['Name','Roll No.','Programme','Semester'],[['Ronit Rajput','E052','B.Tech. CSBS','V']])
para("""Declaration to be completed after verification: I acknowledge the sources and assistance used in this submission. My individually verified contributions and remaining work are stated in Chapter 5. I will not represent simulated results as field measurements or proposed activities as completed work.

Student signature: ____________________   Date: ____________________""")
page('Abstract',"""Smart water systems combine measurement, communication and software to improve the visibility of water distribution. Their practical value depends on distinguishing leakage from legitimate demand changes and unreliable telemetry. Contextual baselines and interpretable alerts are therefore necessary.

This report proposes SmartWater, a Python-based monitoring and decision-support system intended for development across approximately eighteen months. Five research studies are examined through accessible author repositories and benchmark documentation: LeakDB, BattLeDIM, BATADAL, LeakG3PD and the Battle of Water Demand Forecasting. The review identifies implementation opportunities in reproducible evaluation, combined flow-pressure reasoning, separation of telemetry faults from physical events, realistic scenario generation and demand-aware anomaly detection. These are project-level interpretations, not claims that the studies omitted every corresponding capability.

An initial software proof of concept accompanies the proposal. It creates 672 hourly synthetic records, learns an hourly median flow profile from the first 336 records, and evaluates two persistent-threshold detectors on the remaining period. The flow-only detector achieves precision 0.946, recall 0.906 and F1 0.926; the combined flow-pressure detector achieves precision 1.000, recall 0.885 and F1 0.939 on 332 valid test records. Four invalid readings are reported separately. Both detect all three injected leak events with a one-hour delay, while six automated software tests pass. These figures describe a deliberately simplified synthetic example and cannot establish performance on public benchmarks or real infrastructure.

The report contributes a traceable design, runnable code, transparent baseline comparison, evidence register and semester-wise implementation plan. Future work requires full-text verification of the literature, benchmark ingestion, hydraulic simulation, calibrated instrumentation and supervised pilot evaluation. The outcome is a reproducible software starting point.""",1)
page('Table of Contents',level=1)
page_map=json.loads((ROOT/'page_map.json').read_text()) if (ROOT/'page_map.json').exists() else {}
contents=['Acknowledgement, Team Details and Declaration','Abstract','List of Figures, Tables and Abbreviations','Chapter 1 — Introduction','Chapter 2 — Background Study','Chapter 3 — Design and Development Process','Chapter 4 — Implementation, Results and Analysis','Chapter 5 — Individual Contribution, Teamwork and Reflection','Chapter 6 — Conclusion and Future Scope','References','Appendix I — IER and Evidence Register','Appendix II — Data and Interface Specifications','Appendix III — Source Code and Reproduction Guide','Appendix IV — Meeting and Feedback Records','Appendix V — Vertical-Specific Research Evidence','Appendix VI — Publications, IP and External Outcomes','Appendix VII — AI-Tool Use Disclosure and Submission Checklist']
table('Report contents',['Section','Page'],[[c,page_map.get(c,'—')] for c in contents])

page('List of Figures, Tables and Abbreviations',level=1)
table('List of figures',['Figure','Caption','Page'],[[n,t,page_map.get(n,'—')] for n,t in [('Fig. 3.1','Selected architecture'),('Fig. 3.2','Eighteen-month project plan'),('Fig. 4.1','Synthetic telemetry and alerts'),('Fig. 4.2','Detector comparison')]])
table('List of tables',['Table','Caption','Page'],[[n,t,page_map.get(n,'—')] for n,t in [('Table F.1','Student details'),('Table 2.1','Literature comparison'),('Table 3.1','Requirements'),('Table 3.2','Design alternatives'),('Table 3.3','Milestones'),('Table 4.1','Automated tests'),('Table 4.2','Confusion counts'),('Table 5.1','Contribution record'),('Table A.I','Evidence register'),('Table A.II','Data dictionary'),('Table A.IV','Meeting template'),('Table A.VII','AI-use log')]])
table('Abbreviations',['Term','Meaning'],[['AMR','Automatic meter reading'],['API','Application programming interface'],['DMA','District metered area'],['EPANET','Water-network hydraulic modelling software'],['F1','Harmonic mean of precision and recall'],['IER','Individual Evidence Register'],['IoT','Internet of Things'],['MAE','Mean absolute error'],['MVP','Minimum viable product'],['SCADA','Supervisory control and data acquisition'],['WDN','Water distribution network'],['WNTR','Water Network Tool for Resilience']])
body=doc.add_section(WD_SECTION_START.NEW_PAGE);body.footer.is_linked_to_previous=False;numbering(body,'decimal',1)
doc.add_heading('Chapter 1 — Introduction',1)
para("""This chapter defines the water-management problem, intended users and current scope, and separates the initial software artifact from the longer development programme.""")
doc.add_heading('1.1 Background and motivation',2)
para("""A water distribution system is both a physical network and an information system. Pipes, pumps and storage determine how water moves, while measurements determine what an operator can know about that movement. When telemetry is delayed, sparse or misleading, a visible change in consumption can be difficult to interpret. The engineering challenge is therefore not merely to collect more readings, but to translate imperfect observations into useful operational evidence.

LeakDB [1] demonstrates the value of repeatable leakage scenarios for evaluating algorithms. BattLeDIM [2] frames detection and localization around flow and pressure observations and a network model. Together these studies motivate a project that begins with measurable software behaviour and later incorporates physical context. No universal water-loss percentage is assumed here: local losses must eventually be measured using appropriate system boundaries and reliable instruments.

For a CSBS student, the proposed topic connects programming, data analysis, database design, software testing and operational decision-making. A campus building or small distribution zone offers a manageable future use case, provided access and supervision are arranged. The near-term focus is an inspectable software pipeline rather than unsupported claims of municipal-scale deployment.""")
doc.add_heading('1.2 Scope of this submission',2)
para('The current scope includes a documented five-study review, architecture, a synthetic-data generator, two alert algorithms, local database storage, generated charts and automated tests. It excludes installed sensors, verified stakeholder interviews, hydraulic-model calibration, automatic valve control and measured water savings. The eighteen-month plan describes how these missing capabilities could be developed and evaluated.')
page('1.3 Problem statement, stakeholders and objectives',"""Problem statement: Design and evaluate a software system that detects persistent, unusual water-flow behaviour, checks supporting pressure evidence, separates missing data from normal operation, and presents interpretable alerts without using future information during model training.

Proposed users include a facilities operator, maintenance technician, mentor and data owner. They need interpretable events, inspection priorities, reproducible experiments and controlled data access. These inferred needs require stakeholder validation.

The first objective is reproducibility: the same code and random seed should regenerate the same synthetic observations and evaluation. The second is an honest baseline comparison, using flow-only and combined flow-pressure logic under identical test conditions. The third is evidence traceability: every chart and reported score should map to a saved artifact. Later objectives include benchmark validation, confidence-aware alerts and a supervised pilot.

1.4 Expected outcomes: A working Python prototype, structured telemetry storage, interpretable anomaly output, a documented test suite, a literature-to-requirements map and an implementation plan across three semesters. Performance targets for real data remain provisional until normal variability and operational costs are measured.

1.5 Project context and continuity: This is an initial project submission. No earlier team, partner, semester implementation or three-to-four-month activity record has been supplied. The proposed vertical is research-oriented software development, subject to coordinator confirmation. Dates and signatures must reflect actual activity.

1.6 Organization: Chapter 2 reviews the five studies; Chapter 3 explains requirements and design; Chapter 4 records the executable prototype and its results; Chapter 5 addresses contribution and reflection; Chapter 6 provides the conclusion and continuation plan.

Chapter summary: The project is a bounded, coding-focused investigation of interpretable water monitoring. Its immediate evidence is software and synthetic experimentation; its longer-term value must be established through benchmark and field validation.""")
page('Chapter 2 — Background Study',"""This chapter reviews five complementary research studies to derive a practical software project. Leakage diagnosis, attack detection, scenario realism and demand forecasting are related but distinct tasks. The review uses that distinction to avoid treating every anomaly as a leak or every benchmark result as a deployment guarantee.""",1)
doc.add_heading('2.1 Domain context and review method',2)
para("""Water monitoring spans at least three layers. The physical layer contains flow, pressure, demand and storage. The information layer contains sensors, timestamps, communication paths and missing or altered values. The decision layer converts observations into alerts and maintenance actions. BATADAL [3] is relevant because abnormal telemetry may be caused by a cyber-physical attack rather than a pipe failure. LeakG3PD [4] is relevant because an algorithm can only be evaluated meaningfully if scenario assumptions are understood. Water-demand forecasting [5] provides the normal-operation context against which excess consumption may be assessed.

Five studies were selected for their direct relevance to software implementation and the availability of associated research documentation. The selection is purposeful rather than a systematic or exhaustive literature search. It includes two leakage evaluation studies, one cyberattack detection study, one leak-scenario generator and one demand-forecasting study. Publication dates span established benchmarks and recent developments.

Access boundary: Publisher and DOI metadata endpoints were blocked by the execution environment. The review therefore verifies methods and bibliographic identifiers through author-maintained GitHub repositories and the WaterBenchmarkHub catalog [6]. Full paper PDFs were not retrieved or read. Numerical rankings, statistical significance and unverified author conclusions are intentionally not attributed to the papers. The source register records what was actually accessible.

Each study is reviewed under four questions: What problem does it address? What does the accessible documentation establish? What limitations arise when applying it to this project? What coding response is proposed? Unless explicitly identified otherwise, the limitations below are this report’s critical interpretation of transfer and deployment constraints, not quotations from a paper’s limitations section.""")
page('2.2.1 Paper 1 — LeakDB',"""S. G. Vrachimis, M. S. Kyriakou, D. G. Eliades and M. M. Polycarpou, “LeakDB: A benchmark dataset for leakage diagnosis in water distribution networks,” WDSA/CCWI Joint Conference, 2018 [1]. The linked Zenodo DOI identifies the research artifact; the author repository confirms the conference citation.

Problem and contribution: Leakage-detection algorithms need repeatable observations with known events. LeakDB supplies artificially created but realistic scenarios and an evaluation mechanism. The accessible catalog describes 1,000 scenarios for Net1 and 1,000 for Hanoi, including pressures, demands, flow rates and labels at thirty-minute intervals. It distinguishes abrupt and incipient leakage and includes scenarios without leaks. The original repository provides a MATLAB example and scoring implementation.

Strength: This structure makes algorithm comparisons more defensible than testing only a few hand-picked curves. Ground-truth labels and scenario definitions allow researchers to separate a detector failure from uncertainty about when the event occurred. A common evaluation mechanism also reduces ambiguity about what a reported score means.

Project-specific limitations: Synthetic realism is conditional on hydraulic assumptions and demand generation. Success on those scenarios would not alone establish performance under unmodelled sensor drift, intermittent communications or a new network. Complete simulated measurements also differ from a low-cost deployment with few sensors. The original example’s MATLAB dependency is a practical barrier for a Python-first student workflow, although modern Python loaders exist. This is an integration consideration rather than a claim that the underlying research is deficient.

Proposed implementation: Develop a Python adapter that loads scenario files, standardizes units, preserves timestamps and splits complete scenarios into training and held-out sets. Use both a simple detector and an improved detector under identical conditions. Log false alarms, event recall and delay, rather than reporting accuracy alone. Add missing-data and sensor-noise experiments as explicitly labelled modifications.

Current status: The enclosed generator demonstrates the evaluation structure but does not load or reproduce LeakDB. The next deliverable is an adapter verified against an original labelled scenario. Acceptance requires correct sample counts, label alignment and documented differences from the official scoring procedure.""")
page('2.2.2 Paper 2 — BattLeDIM',"""S. G. Vrachimis et al., “Battle of the Leakage Detection and Isolation Methods,” Journal of Water Resources Planning and Management, DOI: 10.1061/(ASCE)WR.1943-5452.0001601 [2]. The original repository confirms the title and DOI but retains a “forthcoming” label; final issue metadata should be checked against the publisher before submission.

Problem and contribution: BattLeDIM compares methods for detecting and locating leakage events from SCADA observations. Its L-Town problem provides historical and evaluation data, a network model and a structured event-submission format. The accessible documentation describes five-minute observations, including 33 pressure sensors, three flow sensors, one tank-level sensor and 82 automatic-meter-reading channels. The nominal model deliberately differs from the simulation’s underlying parameters, which is valuable when assessing robustness to model uncertainty.

Strength: The task goes beyond identifying unusual values. Participants must connect detection to location and time, and the evaluation is framed around a shared operational problem. Historical repair information and model uncertainty make the benchmark more demanding than a perfectly clean, fully known system.

Project-specific limitations: Results from one benchmark cannot establish generalization across pipe materials, demand patterns, sensor placements and operational policies. Accurate pipe localization requires spatial information that the present single-zone prototype does not contain. A small student deployment may also lack the sensor density and network-model detail available in the challenge. These are transfer limits; the benchmark itself explicitly includes uncertainty and should not be described as assuming perfect knowledge.

Proposed implementation: Separate event detection from localization. First compute a zone-level alert from flow and pressure evidence. Later rank candidate zones using several pressure residuals and a verified network representation. Display the contributing sensors and the confidence or ambiguity of the result. When observations cannot discriminate locations, output an inspection area rather than an unjustified exact pipe identifier.

Current status: The prototype implements only corroborated detection and persistence. It has no network graph, hydraulic solver or localization capability. A later experiment should compare detector performance with fewer sensors and evaluate whether confidence falls appropriately when spatial evidence is removed.""")
page('2.2.3 Paper 3 — BATADAL',"""R. Taormina et al., “Battle of the attack detection algorithms: Disclosing cyber attacks on water distribution networks,” Journal of Water Resources Planning and Management, vol. 144, no. 8, Art. 04018048, 2018, DOI: 10.1061/(ASCE)WR.1943-5452.0000969 [3]. Bibliographic details and task descriptions were inspected in the benchmark catalog.

Problem and contribution: A smart water system can be affected by manipulated telemetry and control signals. BATADAL evaluates cyber-physical attack detection using simulated SCADA observations for the C-Town system. Its documented datasets include normal-operation training data, partially labelled attack data and a separate evaluation period. The task considers time-to-detection and classification performance. The catalog describes 43 measurement or state channels alongside the attack label.

Strength: The benchmark draws attention to a critical ambiguity: the monitored value may be unreliable even when the physical system appears plausible. It also highlights the operational importance of detecting an event promptly. Treating every departure from a prediction as a hydraulic leak would ignore this class of problems.

Project-specific limitations: Attack labels do not provide leak labels, and a classifier trained on attacks cannot automatically identify the physical cause of an anomaly. Simulated attack patterns cover a defined threat model, not every possible attacker or communication failure. The presence of an anomaly also does not prove malicious intent; stuck sensors, unit conversion errors and clock drift can create similar observations.

Proposed implementation: Introduce a telemetry-quality stage before leak detection. Check range, timestamp order, duplicate records, flatlining and implausible rate changes. Preserve raw readings and quality flags, and separate “data unavailable,” “measurement suspicious” and “possible hydraulic event.” Add access-controlled ingestion and audit logging when a network service is introduced. Evaluate physical-event and telemetry-event classifications separately.

Current status: The enclosed code detects missing or non-finite inputs and breaks alert persistence across missing readings. It does not implement attack identification, authenticated networking, replay protection or comprehensive sensor-fault diagnosis. Those are planned modules. The practical research question is whether quality checks reduce misleading alarms without hiding genuine physical failures.""")
page('2.2.4 Paper 4 — LeakG3PD',"""M. Pilotto Figueiredo, L. de Souza Oliveira, G. Lucca, A. Correa Yamin, W. Huckembeck dos Santos and T. da Rosa Lopes, “LeakG3PD: A Python Generator and Simulated Water Distribution System Dataset,” in Intelligent Data Engineering and Automated Learning—IDEAL 2024, 2025, DOI: 10.1007/978-3-031-77738-7_7 [4]. The conference-year and publication-year distinction should be retained.

Problem and contribution: A useful leakage dataset should represent the relationship between physical conditions and the generated leak. The author repository describes LeakG3PD as an updated version of LeakDB. Improvements include pressure-dependent leak demand consistent with the WNTR leak equation, addition of Net3, leak nodes inserted along pipes, time-shifted demand patterns and reorganized storage. The catalog describes 500 scenarios per network.

Strength: The generator supports investigation of how scenario assumptions influence detection. Pressure-dependent leakage and spatial placement are more physically motivated than adding an arbitrary constant to a single observation. The Python implementation also fits a coding-focused project and provides a route toward controlled experiments with several networks.

Project-specific limitations: Improved hydraulic consistency still does not make simulation equivalent to field validation. Instrument noise, imperfect calibration, maintenance behaviour and communication failures require explicit modelling or measurement. A scenario collection can also be misleading if nearby samples from the same simulation are randomly distributed across training and test sets. This would allow a model to exploit shared scenario characteristics rather than generalize.

Proposed implementation: Extend scenario-level evaluation across Net1, Net3 and Hanoi. Hold out at least one network or a clearly defined scenario family where feasible. Introduce separate perturbations for noise, missingness and uncertain demand, while retaining the original data for reference. Record seeds, generator parameters and scenario identities in a manifest. Report performance by condition instead of hiding difficult cases within a single average.

Current status: The enclosed generator is an arithmetic time-series toy, not an implementation of LeakG3PD or WNTR. Flow and pressure are coupled through a chosen coefficient solely to exercise software logic. Hydraulic scenario generation is a next-semester milestone. This distinction prevents the initial numerical demonstration from being presented as physically calibrated research.""")
page('2.2.5 Paper 5 — Battle of Water Demand Forecasting',"""S. Alvisi et al., “Battle of Water Demand Forecasting,” Journal of Water Resources Planning and Management, vol. 151, no. 10, 2025, DOI: 10.1061/JWRMD5.WRENG-6887 [5]. The associated wf4bwdf repository provides the full author list, citation metadata and evaluation examples.

Problem and contribution: Reliable short-term demand forecasts support operational planning. The BWDF competition concerns real district-metered areas in a northern Italian city and provides an evaluation framework for demand prediction. Associated software exposes competition iterations and supplementary information, including DMA inflows, weather, calendar information and metadata. The documented previous-week baseline illustrates how a forecast can be constructed without seeing the evaluation week.

Strength: The benchmark links prediction to real demand observations and a shared evaluation workflow. Its iteration-specific interfaces are particularly relevant to avoiding temporal leakage, where information from the future enters a training or preprocessing step. A transparent seasonal baseline is also a useful reference before adopting more complex machine learning.

Project-specific limitations: Forecast accuracy alone does not identify a leak. Unexpected weather, an event or changed occupancy can increase demand without infrastructure failure. Furthermore, behaviour learned from one city or customer mix may not transfer directly to a campus building. Weather and calendar features may be unavailable in a minimal sensor deployment. Forecast residuals should therefore be treated as evidence requiring context, not as a physical diagnosis.

Proposed implementation: Establish hourly or weekly seasonal baselines, then compare regression or tree-based alternatives on rolling-origin splits. Couple positive flow residuals with pressure evidence and telemetry-quality status. Record MAE or RMSE for normal demand prediction separately from leak-event precision, recall and delay. Use calibrated prediction intervals in a later version to expose uncertainty rather than presenting a single forecast as exact.

Current status: The prototype learns one median value for each hour of the day from a fixed training period. Its normal-period MAE is a diagnostic of that simple baseline, not a BWDF competition score or a validated multi-step forecast. No BWDF data, weather covariates or competition evaluation code were executed.""")
page('2.3 Comparative analysis and research gap',level=2)
table('Table 2.1: Literature-to-project comparison',['Study','Transfer limitation','Coding response','Status'],[['LeakDB [1]','Synthetic-to-field transfer; evaluation integration','Scenario adapter and reproducible scoring','Planned; toy harness exists'],['BattLeDIM [2]','Sensor/model dependence; location ambiguity','Corroborated alerts and later zone ranking','Detection prototype only'],['BATADAL [3]','Anomaly cause is ambiguous','Separate data quality from physical events','Missingness implemented'],['LeakG3PD [4]','Scenario assumptions and cross-network transfer','Hydraulic scenarios and stress tests','Toy seed tests only'],['BWDF [5]','Demand residual is not a leak diagnosis','Demand baseline plus supporting pressure','Hourly median implemented']])
para("""The gap is an integration opportunity: combine demand estimation, physical corroboration, data quality and transparent evaluation in a reproducible student project. Establishing research novelty would require broader full-text comparison with existing systems.

The research question is whether pressure corroboration reduces false alarms at an acceptable cost in sensitivity. Controlled comparisons must test this across operating conditions, networks and sensor placements.

Chapter summary: the studies motivate separate evaluation of data quality, demand estimation and physical events. Full-text verification and benchmark experiments remain necessary.""")
page('Chapter 3 — Design and Development Process',"""This chapter translates the review into requirements, evaluates design alternatives and describes a staged architecture. The design favours components that can be tested independently and improved as access to realistic data becomes available.""",1)
doc.add_heading('3.1 Stakeholder needs and specifications',2)
para('Requirements are proposed from the intended operator workflow. They must be reviewed with the mentor and a future site representative before hardware procurement or a pilot. Each requirement has a measurable check so that implementation does not rely solely on screenshots or verbal claims.')
table('Table 3.1: Functional and non-functional requirements',['ID','Requirement','Verification'],[['R1','Ingest timestamped flow and pressure with explicit units','Schema and unit-conversion tests'],['R2','Keep training separate from future observations','Training-invariance test'],['R3','Recognize missing inputs without calling them normal','Missingness count and persistence-reset test'],['R4','Require persistent evidence before an alert','Known sequence test'],['R5','Compare flow-only and corroborated alerts','Identical held-out test records'],['R6','Preserve measurements and decisions for review','CSV, JSON and database consistency'],['R7','Explain alert evidence to an operator','Future interface review'],['R8','Run without paid cloud services for the first stage','Local Python execution'],['R9','Record versions, parameters and test outcomes','Reproduction checklist'],['R10','Avoid autonomous control in the initial pilot','Read-only operating procedure']])
para('Requirements R2–R6 are represented in the current prototype at a basic level. R1 currently accepts generated in-memory values rather than a production ingestion endpoint. R7 and production-scale performance requirements are not yet validated. A future latency target should be defined against actual sampling rates and operator needs, not chosen simply because the software can run quickly.')
page('3.2 Design alternatives and decision matrix',"""Three implementation routes were considered. A fixed threshold is easy to explain but may confuse normal demand changes with leakage. A deep learning model may capture complex patterns but requires representative data, careful tuning and stronger explanations. A seasonal baseline with physical corroboration provides an intermediate starting point: its decisions are inspectable and its components can be evaluated separately.

The following matrix is a preliminary design judgment, not an experimental result. Scores range from 1 (least suitable) to 5 (most suitable). Weights reflect the needs of an initial student project: interpretability 30%, low-data suitability 25%, implementation feasibility 25% and adaptability 20%. Stakeholder input could change these weights.""")
table('Table 3.2: Weighted design alternatives',['Alternative','Interpret.','Low data','Feasible','Adaptable','Total / 5'],[['Fixed threshold',5,4,5,2,'4.15'],['Deep learning',2,1,2,5,'2.35'],['Seasonal + corroboration',5,4,4,4,'4.30']])
para("""The selected approach estimates the typical flow for each time-of-day slot, measures excess flow, checks pressure reduction and requires repeated supporting samples. This is a hypothesis about an appropriate starting point, not evidence that the method will outperform every neural network. Complexity can be added later if a well-designed benchmark comparison justifies it.

Storage also follows a staged decision. CSV supports inspection and interchange; JSON stores experiment summaries; SQLite provides a lightweight relational record without requiring a separate database service. A later multi-user application may need PostgreSQL, authentication and backup policies. The current static HTML report is useful for review but does not provide live ingestion or a complete operator workflow.

Design trade-off: requiring pressure confirmation reduces sensitivity to leaks with a weak pressure signature. That cost must remain visible. The interface should eventually support an “unconfirmed high-demand event” state rather than silently discarding every flow anomaly that lacks corroboration.""")
page('3.3 Selected architecture and algorithm',"""The architecture separates data generation or acquisition, validation, baseline estimation, detection, storage and presentation. The current implementation combines these modules in a small Python file for readability, while preserving separate functions for generation, fitting, detection and scoring. Later refactoring can turn these boundaries into independently tested modules.

The baseline is b(h) = median of training flow observations recorded at hour h. For observation t, excess flow is r(t) = q(t) − b(hour(t)). A candidate flow event occurs when r(t) > 3 L/min. The hybrid detector additionally requires p0 − p(t) > 0.8 m, where p0 is the training-period median pressure. An alert requires two consecutive candidate observations. An invalid observation resets the consecutive count. These thresholds are demonstration parameters, not calibrated engineering limits.

The two-sample persistence rule helps reject isolated excursions but creates a minimum one-sample delay. At the hourly demonstration rate this is one hour. A five-minute sensor stream would change the time represented by the rule and require new validation. Sample-based and time-based policies must not be confused.

The output record should eventually include event identifier, zone, start time, observed values, baseline, residuals, quality status, detector version and an explanation. The current exported data include observations, labels, expected flow and both alert sequences; structured per-event explanation records remain future work.""")
# architecture figure generated separately
fig('architecture.png','Fig. 3.1: Selected architecture. Solid-stage labels identify current functions; future acquisition and operator workflow are explicitly marked.')
page('3.4 Constraints, standards and responsible design',"""Water-related software must respect the difference between monitoring and physical control. A false alert wastes inspection effort, while a missed event may delay repair. A command to close a valve can also interrupt service. The initial system therefore produces advisory outputs and does not actuate pumps or valves. Any later control experiment requires supervision, a safe testbed, a manual override and a documented approval process.

Data constraints include sampling interval, unit consistency, sensor calibration, clock synchronization, gaps and uncertain labels. Flow is expressed in litres per minute in the toy demonstration; pressure is expressed as metres of head. Real sensors may report litres per hour, cubic metres per hour, bar or kilopascals. Conversion should be explicit, with tests and metadata, before values reach a detector.

Security and privacy requirements include minimizing household-level identifiers, restricting access to telemetry, protecting credentials, retaining audit records and defining data retention. Aggregated building-level measurements are preferable where they answer the research question. This report contains no personal consumption records. The relevance of attack detection follows from BATADAL [3], but the current offline prototype is not a security-certified system.

Standards position: IEEE-style referencing is used as required by the supplied institutional format. No claim of conformance to an IEEE, ISO, IEC or drinking-water quality standard is made, because such conformance was not assessed. Before a field pilot, the mentor and site owner should identify the applicable electrical, plumbing, data-protection and institutional requirements. Flow and pressure monitoring alone cannot establish that water is safe to drink.

Environmental impact should be measured rather than assumed. A future water-savings estimate needs a verified baseline, a confirmed leak, a known repair time and uncertainty bounds. The current prototype cannot estimate actual water saved, economic payback or reduced emissions. Budget estimates must likewise be supported by quotations before being presented as approved expenditure.""")
page('3.5 Work breakdown and eighteen-month plan',"""The programme is organized into three six-month stages. The first produces a reproducible software foundation and a verified literature review. The second adds public-benchmark evaluation, hydraulic realism and a usable interface. The third evaluates a supervised pilot, documents limitations and prepares the final handover. This is a prospective plan; it is not a reconstructed history of work already completed.""")
table('Table 3.3: Semester-wise deliverables and acceptance gates',['Period','Work package','Evidence required'],[['Months 1–2','Verify papers; define stakeholder needs; reproduce code','Reading notes, approved scope, run logs'],['Months 3–4','Load one public benchmark; establish baselines','Adapter tests, scenario manifests, scores'],['Months 5–6','Complete first review and design freeze','Semester report, demo, mentor feedback'],['Months 7–9','Hydraulic simulation and robust evaluation','Cross-scenario results and ablations'],['Months 10–12','Dashboard, quality flags and sensor testbed','Usability notes, calibration records'],['Months 13–15','Supervised pilot if access is approved','Consent/access record, labelled events'],['Months 16–18','Evaluate, refine and hand over','Final report, reproducible release, viva']])
fig('timeline.png','Fig. 3.2: Prospective eighteen-month project schedule. No bar represents completed historical activity.')
para('Dependency management: benchmark access precedes performance claims; calibration precedes field comparisons; site authorization precedes installation; operator feedback precedes usability claims. If a field partner is unavailable, the final evaluation can remain a carefully bounded benchmark and testbed study. Chapter summary: the selected design balances interpretability and implementation feasibility, with explicit gates for increasing realism and operational responsibility.')
page('Chapter 4 — Implementation, Results and Analysis',"""This chapter reports the software that was actually generated and executed for this submission. All numerical outcomes arise from synthetic data created by the included program. They are evidence that the demonstration and its tests run, not evidence of field deployment or a semester-long experimental campaign.""",1)
doc.add_heading('4.1 Implemented software and experiment',2)
para("""The implementation uses Python, NumPy, Matplotlib and the standard-library SQLite interface. The generator produces 28 days of hourly observations, for 672 total samples. Normal flow follows a smooth daily profile with random noise. Pressure fluctuates around a chosen mean. Three leak intervals add flow and reduce pressure: a 24-hour event beginning at hour 384, a 48-hour event at hour 456 and a 24-hour event at hour 600. Their added flows are 7, 4 and 9 L/min respectively.

The test period also contains a six-hour legitimate high-flow episode without a pressure reduction, four missing flow readings and a five-hour pressure-only disturbance. These counterexamples are important because a detector should not treat every abnormal channel as sufficient evidence of leakage. The construction is intentionally simple and favours the physical relationship assumed by the hybrid detector.

The first fourteen days, or 336 samples, train the hourly median profile and reference pressure. The remaining 336 samples form the evaluation period. Four invalid observations are excluded from binary confusion counts and reported separately. Consequently, the scored test set contains 332 samples, including 96 leak samples and 236 non-leak samples. Ground-truth labels are used for evaluation, not passed to the detector.

The program writes telemetry.csv, metrics.json, water.db, dashboard.html and two charts. Re-running it replaces records by hour within the local database instead of creating duplicate observations. These files are accompanied by six tests and a run instruction file. The output is an initial local proof of concept, not a deployed web application.""")
page('4.2 Testing, validation and verification',"""A meaningful test plan must check behaviour that would fail if the implementation were wrong. Determinism verifies that a chosen seed reproduces the generated experiment. Training invariance verifies that modifying the future observations does not alter the fitted baseline. Sequence tests verify missing-data handling and persistence. Counterexample tests verify that pressure-only or flow-only changes do not trigger the hybrid rule. A separate scoring test checks known confusion counts and event delay.

The executed unit tests are listed below. They test software logic; they do not validate the chosen physical model or prove that the thresholds are appropriate for a real network. Those questions require a different type of evidence.""")
table('Table 4.1: Executed automated checks',['Test','Failure it guards against','Result'],[['Deterministic generation','Unrepeatable synthetic inputs','PASS'],['Training independence','Future information changes training','PASS'],['Missingness resets persistence','Alerts bridge missing observations','PASS'],['Pressure-only disturbance','Unsupported leak inference','PASS'],['Flow-only disturbance','Missing pressure corroboration','PASS'],['Metric/event scoring','Incorrect counts or delay','PASS']])
para("""Evaluation measures: precision = TP/(TP+FP); recall = TP/(TP+FN); F1 = 2PR/(P+R). Event recall counts whether each complete leak interval contains at least one alert. Detection delay measures time from event onset to its first alert. Sample-level and event-level measures answer different questions: an event can be found even if several of its samples are missed.

The ten-seed check varies random noise while preserving the same scenario design, thresholds and event structure. It is a sensitivity check, not independent external validation. Future work should include threshold selection on a separate validation period, held-out scenario families, different networks and confidence intervals over independent events.""")
page('4.3 Results and analysis',level=2)
table('Table 4.2: Held-out synthetic results, seed 42',['Measure','Flow-only','Hybrid'],[['TP / FP','87 / 5','85 / 0'],['FN / TN','9 / 231','11 / 236'],['Precision','0.9457','1.0000'],['Recall','0.9063','0.8854'],['F1','0.9255','0.9392'],['Detected events','3 / 3','3 / 3'],['Delays (hours)','1, 1, 1','1, 1, 1'],['Invalid samples excluded','4','4']])
fig('results.png','Fig. 4.1: Generated flow, baseline, pressure and hybrid alerts. The dashed line marks the training/test boundary.')
para('The flow-only detector generates five false-positive samples during legitimate high usage. Pressure corroboration removes these in this experiment but also reduces true-positive samples by two. Both methods identify all three events after one hour. Event recall therefore remains unchanged while sample recall falls. This distinction is essential: “all events detected” does not mean that every leak sample was classified correctly.')
page('4.3.1 Interpretation, robustness and threats to validity',level=2)
fig('comparison.png','Fig. 4.2: Precision, recall and F1 on the synthetic held-out period. These scores are not comparable to published benchmark rankings.')
para(f"""Across seeds 0–9, the hybrid detector’s F1 ranges from {M['ten_seed_f1']['min']:.4f} to {M['ten_seed_f1']['max']:.4f}, with mean {M['ten_seed_f1']['mean']:.4f}. The normal-period flow baseline has MAE {M['normal_period_mae_lpm']:.4f} L/min for seed 42. This MAE excludes labelled leaks and invalid samples but includes the legitimate high-demand episode. It should not be described as a competition forecasting result.

Internal validity: the generator intentionally couples leakage with a pressure reduction and adds legitimate high usage without a pressure reduction. This makes corroboration useful by construction. The observed advantage therefore demonstrates a mechanism, not general superiority. Thresholds were chosen for the illustration and were not selected through an independent validation process. Only three distinct events are present, so event-level percentages are unstable.

External validity: there is no hydraulic solver, actual pipe topology, hardware noise characterization or field ground truth. Real leaks may produce weak pressure changes, and real demand surges may reduce pressure. Both situations could reverse the apparent advantage. Hourly sampling is also too coarse for many operational responses.

Measurement validity: invalid readings are excluded from classification counts but remain visible as missingness. A future availability-aware evaluation should penalize prolonged outages and assess events that occur entirely within gaps. The present demonstration has no such leak-gap overlap. There is also no calibrated confidence score or uncertainty interval.""")
page('4.3.2 Code excerpts, recorded output and findings',level=2)
para('The following excerpts are taken from the executed implementation. The full source file is provided as E02. The hourly baseline uses only observations before train_end, while the candidate condition uses current flow and pressure. Labels do not enter these calculations.')
code = "baseline = profile[np.arange(len(flow)) % 24]\nvalid = np.isfinite(flow) & np.isfinite(pressure)\ncandidate = valid & ((flow - baseline) > 3)\nif mode == 'hybrid':\n    candidate &= ((p0 - pressure) > .8)\nrun = 0\nfor i, flag in enumerate(candidate):\n    run = run + 1 if flag else 0\n    alert[i] = run >= 2"
for line in code.splitlines():
 p=doc.add_paragraph(line);p.paragraph_format.line_spacing=1;p.paragraph_format.space_after=Pt(0)
 for r in p.runs:r.font.size=Pt(10)
para('Interpretation: valid prevents missing values from being treated as evidence. The logical AND means both channels must support a hybrid event. Resetting run on a failed condition makes persistence consecutive, rather than allowing unrelated isolated anomalies to accumulate. This is also why weak pressure evidence can interrupt a true leak alert.')
para('Recorded seed-42 output from results/metrics.json:')
output = {k:M['models']['hybrid'][k] for k in ['tp','fp','fn','tn','precision','recall','f1','evaluated_samples','missing_samples','events_detected','events_total','detection_delays_hours']}
for line in json.dumps(output,indent=2).splitlines():
 p=doc.add_paragraph(line);p.paragraph_format.line_spacing=1;p.paragraph_format.space_after=Pt(0)
 for r in p.runs:r.font.size=Pt(10)
page('4.3.3 Execution evidence and what the code establishes',level=2)
para('The test log below records the current execution. These checks exercise deterministic generation, temporal separation, counterexamples, persistence and metric calculations. Test duration is environment-dependent and is not a performance benchmark.')
log=(ROOT/'results/tests.txt').read_text()
log=log[log.find('test_deterministic'):]
for line in log.splitlines():
 p=doc.add_paragraph(line);p.paragraph_format.line_spacing=1;p.paragraph_format.space_after=Pt(1)
 for r in p.runs:r.font.size=Pt(9)
para('Code finding 1: pressure corroboration blocks the synthetic high-demand false alarms. The mechanism is visible directly in the AND condition, and its effect is measured by the reduction from five false-positive samples to zero.')
para('Code finding 2: the same condition removes some true-positive samples. Recall falls by approximately 2.08 percentage points. This is a meaningful cost of requiring an additional measurement channel to agree.')
para('Code finding 3: persistence delays event recognition. All three events first trigger after one hourly interval. The algorithm therefore cannot honestly be described as instantaneous, regardless of how quickly Python processes a sample.')
para('Code finding 4: missing observations reduce evaluated coverage. Four of 336 held-out samples are invalid, giving 98.81% valid coverage. Reporting only the 332 scored samples would hide that availability issue.')
para('Code finding 5: reproducibility is stronger than deployment evidence. Passing six tests and regenerating identical synthetic outputs establishes specific software properties. It does not establish sensor accuracy, hydraulic realism, cyberattack detection or generalization to unseen physical networks.')
page('4.4 Feedback, iteration and impact',"""No mentor review, stakeholder interview or field feedback was supplied or conducted for this report. The first planned review should ask whether the problem is appropriate for the course, whether the proposed vertical is correct, and whether the first semester should emphasize public-data evaluation or instrumentation. Feedback must be recorded with its actual date and translated into a tracked decision.

The current experiment already suggests useful technical iterations. First, expose an unconfirmed flow-anomaly state so that pressure corroboration does not hide all weak-signature events. Second, distinguish data-quality alarms from physical alarms. Third, replace hand-selected thresholds with a documented validation process. Fourth, compare complete events and detection delay, not only sample F1. Fifth, test against demand surges that also lower pressure and leaks that have little measurable pressure effect.

Potential advantages are low software cost, inspectable logic, a small dependency set and easy reproduction. Potential applications include educational testbeds, facilities monitoring and research comparisons. The system is currently unsuitable for unattended operational decisions because it lacks calibrated sensors, reliable ingestion, authorization, monitoring of its own health and verified performance on representative data.

An impact study would require a baseline period, independently confirmed events and a record of interventions. A future estimate of avoided loss should integrate excess flow over the difference between observed response time and a defensible counterfactual response time. It should include uncertainty, false-alarm costs and maintenance effort. No such savings calculation is supported by the current toy data.

Chapter summary: The prototype executes, its six software tests pass, and the synthetic comparison exposes a useful sensitivity–false-alarm trade-off. It does not validate deployment, localization, cyberattack diagnosis or water savings. These limits guide the next experiments rather than being hidden by a single favourable score.""")
page('Chapter 5 — Individual Contribution, Teamwork and Reflection',"""This chapter separates available artifacts from the student’s personally verified contribution. A generated report is not an Individual Evidence Register by itself. The student should reproduce the code, explain its decisions and replace pending entries with genuine evidence as work progresses.""",1)
doc.add_heading('5.1 Team structure and roles',2)
para('Ronit Rajput, E052, is the only student identified for this submission. Dr Poulami Das Ray is the named mentor. No additional team members, industrial partner or community partner are assumed. If a team is later formed, each member must have an individual contribution statement and evidence references. The proposed student role covers source verification, programming, experiments and reporting, subject to mentor agreement.')
table('Table 5.1: Contribution and verification record',['Activity','Available evidence','Attribution / status'],[['Problem and constraints','Current request and project scope','Specified by Ronit'],['Literature synthesis','E01: source files and report','AI-assisted draft; student verification pending'],['Prototype and tests','E02–E04: code and test log','AI-generated and executed in this preparation session'],['Analysis and visualizations','E05: metrics and charts','Derived from actual synthetic run'],['Personal reproduction','E06: student execution log','Pending; no completed work claimed'],['Mentor review','E07: review record','Pending'],['Field work','E08: pilot and calibration records','Not undertaken']])
para('Before claiming ownership of an implementation decision, the student should be able to explain the code path, modify it, predict the effect of a change and reproduce the result. Appropriate evidence includes a personally recorded run log, annotated experiment notebook and a short demonstration. Merely changing wording or a name does not constitute technical contribution.')
page('5.2–5.5 Teamwork, reflection and professional conduct',"""Coordination plan: schedule a short mentor review at each milestone, prepare a specific technical question, record the decision and attach the resulting change. Where responsibilities are shared, assign an owner and reviewer for each output. No historical meetings or peer feedback are asserted in this report. Appendix IV supplies a blank record for future use.

Reflection prompts for Ronit: Why is flow-only detection insufficient? Under which conditions can pressure corroboration fail? What does the missing-data rule prevent? Why is the toy simulator not a hydraulic model? Which conclusions can be drawn from three events, and which require more evidence? Answers should be written after personally executing the program and reviewing the cited sources.

A technical lesson illustrated by the experiment is that a higher F1 score can coexist with lower recall. The hybrid detector removes false-positive samples while missing two additional true-positive samples. Whether that is preferable depends on the cost of unnecessary inspection versus delayed leak recognition. The project should therefore discuss operating objectives before selecting a final threshold.

A second lesson is the importance of provenance. A picture of a time series does not establish that it came from a sensor, and a planned task is not evidence of completed work. The report uses explicit labels for synthetic data, proposed activities and verification still required. This makes the work easier to extend and defend in a viva.

AI-use disclosure: ChatGPT assisted with research-source retrieval, source synthesis, requirements, software generation, execution, analysis, writing and presentation construction. The software was run and tested in the preparation environment. Full publisher PDFs were not accessed, and student verification has not been observed. The student must follow MPSTME’s policy, verify the artifacts and make any permitted-use declaration required by the mentor. Appendix VII contains a detailed log.

Chapter summary: Available artifacts support an initial technical demonstration, while student reproduction, mentor feedback and fieldwork remain pending. Future contribution records should attach real outputs to actual dates and responsibilities.""")
page('Chapter 6 — Conclusion and Future Scope',"""This chapter provides the report’s single overall conclusion and sets out a practical continuation path. It draws only on the documented review and executed synthetic experiment.""",1)
doc.add_heading('6.1 Conclusion',2)
para("""SmartWater is a feasible coding-focused direction for an eighteen-month design project. The five reviewed studies motivate reproducible evaluation, contextual interpretation of flow and pressure, explicit treatment of telemetry quality, physically meaningful scenarios and demand-aware baselines. The present contribution is an initial software foundation and design proposal, not a completed operational water-management system.

The executed experiment shows that pressure corroboration can reduce false alerts under the chosen synthetic assumptions. It improves F1 from 0.9255 to 0.9392 while reducing recall from 0.9063 to 0.8854. Both methods detect three injected events with one-hour delay, and six automated tests pass. The small, purpose-built scenario does not establish real-world accuracy or research novelty. Its value is that the result is reproducible and its trade-off is visible.""")
doc.add_heading('6.2 Future scope and handover',2)
para("""The next actions are to verify the five full papers, obtain mentor feedback, reproduce the code personally and implement one public-benchmark adapter. The following semester should add scenario-level evaluation, realistic hydraulic simulations, uncertainty reporting and a better operator interface. The final semester can evaluate a supervised sensor testbed or approved field pilot, depending on access and resources.

The handover package contains source code, tests, synthetic observations, machine-readable scores, charts, a local database, a static dashboard, source notes and run instructions. Future work should preserve the baseline as a reference, version every experiment and document why a change was made. Completed activities should be entered into the evidence register as they occur.

Closing summary: further progress requires verified implementation, critical comparison, personal understanding and stronger evidence.""")
page('References',level=1)
refs=[
'[1] S. G. Vrachimis, M. S. Kyriakou, D. G. Eliades, and M. M. Polycarpou, “LeakDB: A benchmark dataset for leakage diagnosis in water distribution networks,” in Proc. WDSA/CCWI Joint Conf., vol. 1, 2018. Associated research artifact: https://doi.org/10.5281/zenodo.1313116. Author documentation: https://github.com/KIOS-Research/LeakDB.',
'[2] S. G. Vrachimis et al., “Battle of the Leakage Detection and Isolation Methods,” Journal of Water Resources Planning and Management, doi: 10.1061/(ASCE)WR.1943-5452.0001601. Author documentation: https://github.com/KIOS-Research/BattLeDIM. Final publication year, volume and issue require publisher verification; accessible repository citation retains “forthcoming.”',
'[3] R. Taormina et al., “Battle of the attack detection algorithms: Disclosing cyber attacks on water distribution networks,” Journal of Water Resources Planning and Management, vol. 144, no. 8, Art. 04018048, 2018, doi: 10.1061/(ASCE)WR.1943-5452.0000969.',
'[4] M. Pilotto Figueiredo, L. de Souza Oliveira, G. Lucca, A. Correa Yamin, W. Huckembeck dos Santos, and T. da Rosa Lopes, “LeakG3PD: A Python Generator and Simulated Water Distribution System Dataset,” in Intelligent Data Engineering and Automated Learning—IDEAL 2024, 2025, doi: 10.1007/978-3-031-77738-7_7. Author documentation: https://github.com/matheuspilotto/LeakG3PD.',
'[5] S. Alvisi et al., “Battle of Water Demand Forecasting,” Journal of Water Resources Planning and Management, vol. 151, no. 10, 2025, doi: 10.1061/JWRMD5.WRENG-6887. Associated implementation and citation: https://github.com/WaterFutures/wf4bwdf.',
'[6] A. Artelt, K. Giese, S. G. Vrachimis, D. G. Eliades, M. M. Polycarpou, and B. Hammer, “The WaterBenchmarkHub: A Platform for Benchmarks in Water Distribution Networks,” 21st Computing and Control in the Water Industry Conference, 2025, doi: 10.15131/SHEF.DATA.29921051.V1. Catalog: https://github.com/WaterFutures/WaterBenchmarkHub.'
]
for r in refs:para(r)

page('Appendix I — IER and Evidence Register',level=1)
table('Table A.I: Evidence register',['ID','Artifact','Location / verification'],[['E01','Inspected research documentation','sources/; author or catalog text'],['E02','Python implementation','code/smartwater.py'],['E03','Automated tests','code/test_smartwater.py'],['E04','Executed test log','results/tests.txt; six passed'],['E05','Synthetic results','results/metrics.json; telemetry.csv; figures/'],['E06','Student reproduction record','Pending; to be created by Ronit'],['E07','Mentor feedback','Pending; use Appendix IV'],['E08','Calibration / pilot observations','Not available; future work']])
para("""Evidence-handling procedure: Record the activity date, author, code version, input origin, command and output path for each experiment. Preserve failed runs where they explain a change. If a chart is regenerated, retain the corresponding parameters and results rather than leaving the image disconnected from its source.

The current package was prepared in one assistance session. Synthetic elapsed days are simulation coordinates, not calendar dates of work. Repository commit history, screenshots or meeting minutes must not be fabricated to imply an earlier start. New evidence should be added when the student performs and verifies the corresponding task.

For each semester review, select evidence that demonstrates the required competencies: implementation for individual accomplishment, alternatives for design process, failure analysis for reflection, real coordination records for teamwork, and a reproducible report and demo for communication. A complete folder is useful only if the student can explain its contents.""")
page('Appendix II — Data and Interface Specifications',level=1)
table('Table A.II: Current output schema',['Field','Type / unit','Meaning'],[['hour','Integer, hours','Elapsed synthetic time, 0–671'],['flow_lpm','Float, L/min','Observed generated flow; NaN when missing'],['pressure_m','Float, metres head','Observed generated pressure'],['leak_truth','Boolean encoded 0/1','Evaluation label; never detector input'],['expected_flow_lpm','Float, L/min','Training-derived median for time slot'],['flow_only_alert','Boolean encoded 0/1','Persistent flow condition'],['hybrid_alert','Boolean encoded 0/1','Persistent combined condition']])
para("""Proposed live-ingestion record: timestamp_utc, site_id, sensor_id, measurement_type, value, unit, quality_flag and sequence_number. A separate metadata record should contain device model, calibration date and authorized owner. The ingestion boundary should reject unsupported units and preserve the original payload for diagnosis without exposing credentials.

Recommended event record: event_id, zone_id, start_time, last_update, detector_version, contributing_sensors, residual_summary, quality_status, confidence_status and operator_disposition. This is a proposed interface, not a feature already present in the included code.

Future hardware specifications depend on the selected site. Flow range, pressure range, power, enclosure, sampling interval and calibration procedure should be chosen from actual requirements and verified datasheets. No bill of materials or pin diagram is presented as finalized because no hardware has been selected or procured. Keeping this decision open avoids selecting a low-cost component that cannot measure the intended conditions accurately.""")
page('Appendix III — Source Code and Reproduction Guide',level=1)
para("""The complete implementation and tests accompany this report in the code directory. Requirements are Python 3.10 or newer, NumPy and Matplotlib; SQLite and unittest come with Python. From the extracted smartwater directory, create a virtual environment if needed, install the listed dependencies, then run the following commands:

python -m pip install -r code/requirements.txt
python code/smartwater.py
python -m unittest discover -s code -v

Open results/dashboard.html in a browser to inspect the static demonstration. It reads generated images through relative file paths and does not require a server. The page is a report viewer, not a live operational dashboard.

Expected output: 672 telemetry records, a JSON metrics file, SQLite storage and two plots. The seed-42 hybrid confusion counts should be TP=85, FP=0, FN=11 and TN=236. The test suite should execute six tests and finish with OK. Small numerical or plotting differences across library versions should be investigated; the saved dependency versions identify the preparation environment.

Core algorithm pseudocode: Fit the hourly median flow profile and global median pressure from the training interval. For each observation, first check finite inputs. Compare excess flow with its threshold. For the hybrid model, also compare pressure drop with its threshold. Increment a consecutive count only if all required conditions hold; otherwise reset it. Emit an alert when the count reaches two. Score the held-out observations after removing invalid records and separately count missingness.

Suggested student experiment: change one threshold, state the predicted effect before running, regenerate results, and explain any mismatch between prediction and observation. Preserve both runs. This is a useful first independently verifiable contribution.""")
page('Appendix IV — Meeting and Feedback Records',level=1)
para('No completed meeting record is claimed. Use the following template for an actual mentor or team discussion. Populate it immediately after the meeting and confirm the decisions with participants where appropriate.')
table('Table A.IV: Blank meeting record',['Field','To be completed'],[['Actual date and time','[Enter after meeting]'],['Participants','[Names and roles]'],['Artifacts reviewed','[Evidence IDs / versions]'],['Questions raised','[Specific technical questions]'],['Feedback received','[Accurate notes, not assumed comments]'],['Decision and rationale','[Agreed action and reason]'],['Owner and due date','[Responsible person / date]'],['Follow-up evidence','[Code, report section or experiment]']])
para("""Proposed first-review agenda: confirm the Design Experience stage and vertical; approve the project scope; discuss whether source verification is sufficient; decide the first benchmark to load; agree on individual contribution evidence; identify any conditions for future hardware access.

A useful review question is whether the comparison should optimize fast detection, low false-alarm burden or sensitivity to small leaks. The answer changes threshold selection and the preferred metrics. Record that choice before running a large evaluation so that performance reporting does not simply favour whichever measure looks best afterward.

Peer feedback, if a team is later formed, should describe an observed contribution, its impact and one actionable improvement. Do not invent peer roles or signatures to fill a template.""")
page('Appendix V — Vertical-Specific Research Evidence',level=1)
para("""The provisional emphasis is a research-oriented software project. The core evidence should therefore include a well-defined research question, source comparison, repeatable experiment, baseline, analysis of failure cases and a record of changes. The official vertical still requires confirmation by the coordinator.

Hypothesis H1: corroborating sustained flow anomalies with pressure evidence reduces false alerts caused by increased legitimate consumption. Hypothesis H2: that reduction is accompanied by missed weak-pressure-signature leak samples. The synthetic run is consistent with both mechanisms under its construction, but cannot establish that they hold across real networks.

A stronger experiment should use several complete scenarios and preserve their identities through splitting. Fit preprocessing only on the training portion. Select thresholds using validation data. Freeze the settings before scoring the test set. Compare the same events across methods and report both favourable and unfavourable conditions. When events are rare, summarize false alarms per unit of valid operating time in addition to precision and recall.

Ablations should remove pressure corroboration, change persistence duration, vary missingness and increase measurement noise one factor at a time. An additional test should include a legitimate demand surge that reduces pressure, because this directly challenges the hybrid rule. A leak with little observable pressure change is another necessary counterexample.

The result of a research project may be a documented limitation rather than a new state-of-the-art algorithm. Demonstrating when a simple method fails, with reproducible evidence and a justified redesign, is a meaningful technical outcome. Novelty and publication suitability must be discussed with the mentor after broader full-text review.""")
page('Appendix VI — Publications, IP and External Outcomes',level=1)
para("""No publication, patent filing, competition participation, award, industrial deployment or external validation is claimed for SmartWater. The five research studies reviewed in Chapter 2 are external works and are not publications by the student.

This appendix is retained to match the institutional report structure. If later work produces a poster, conference submission, competition entry or intellectual-property disclosure, record its actual title, date, contributors, status and evidence. Distinguish submitted, under review, accepted and published outcomes. A draft manuscript does not imply acceptance.

Before releasing a future dataset or source repository, review ownership, source licences, institutional intellectual-property rules and any site agreement. The included synthetic observations do not identify a real facility. Public research data should remain attributed to their original creators, and redistribution should follow the relevant licence rather than assuming that download access permits every use.

A future handover should identify which parts were written by the student, which were generated with assistance and which were adapted from third-party code. Preserve licence notices and relevant citations. The current prototype was generated for this submission and does not reproduce the benchmark authors’ implementations.

Suggested final-semester record: artifact title; student authors and contributions; mentor approval date; external venue or repository; submission status; persistent identifier; supporting evidence; restrictions or pending permissions. Leave this record unfilled until an actual outcome exists.""")
page('Appendix VII — AI-Tool Use Disclosure and Submission Checklist',level=1)
table('Table A.VII: Assistance and verification log',['Use','Assistance provided','Verification boundary'],[['Research','Retrieved author and catalog documentation','Full publisher PDFs not accessed'],['Writing','Drafted structure, analysis and plan','Student/mentor review pending'],['Coding','Generated Python pipeline and tests','Executed; six tests passed'],['Analysis','Calculated metrics and drew charts','Derived from saved synthetic outputs'],['Presentation','Generated editable PowerPoint','Canva import not tested here']])
para("""Before submission, Ronit should verify each study against its full text, check all unresolved bibliographic details, execute the program personally, confirm that the numbers match the saved outputs and remove or revise any statement he cannot explain. The declaration and certificate should be signed only after the relevant verification. The use of AI must be permitted by the institution and disclosed as required.

Administrative checks: enter SAP ID; confirm the Design Experience stage and vertical; check the mentor’s designation and department; confirm the academic year; refresh the contents and lists; obtain the required signatures; follow the coordinator’s similarity-check process. No similarity or plagiarism clearance has been performed in this session.

Formatting note: the editable document specifies A4, Times New Roman 12-point body text, 1.5 spacing, a 1.5-inch left margin and 1-inch remaining margins. Chapter and section headings use 18 and 14 points. The local PDF renderer substitutes Liberation Serif where Times New Roman is unavailable. For strict font compliance, export the editable document from a computer with licensed Times New Roman installed.

Completion status: initial prototype prepared; student verification, full-text review and institutional certification remain pending.""")
doc.save(ROOT/'SmartWater_Report.docx')
(ROOT/'report_references.json').write_text(json.dumps(refs,indent=2))
print('Saved report',len(doc.paragraphs),'paragraphs')
