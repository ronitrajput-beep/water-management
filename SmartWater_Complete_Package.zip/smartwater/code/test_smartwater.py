import unittest
import numpy as np
from smartwater import generate,fit,detect,metrics
class SmartWaterTests(unittest.TestCase):
 def test_deterministic(self):
  a=generate();b=generate()
  for x,y in zip(a,b):np.testing.assert_equal(x,y)
 def test_no_training_leak(self):
  t,f,p,y=generate();a=fit(f,p);f[336:]=999;p[336:]=-999;b=fit(f,p)
  np.testing.assert_equal(a[0],b[0]);self.assertEqual(a[1],b[1])
 def test_missing_breaks_persistence(self):
  f=np.array([10.,10.,np.nan,10.,10.]);p=np.zeros(5);a,v,b=detect(f,p,np.zeros(24),10.)
  np.testing.assert_equal(a,[False,True,False,False,True]);self.assertFalse(v[2])
 def test_pressure_only_not_leak(self):
  a,_,_=detect(np.zeros(10),np.zeros(10),np.zeros(24),10.);self.assertFalse(a.any())
 def test_flow_only_needs_corroboration(self):
  a,_,_=detect(np.full(10,10.),np.full(10,40.),np.zeros(24),40.);self.assertFalse(a.any())
 def test_event_and_false_alarm_scoring(self):
  m=metrics(np.array([0,1,1,0],bool),np.array([0,0,1,1],bool),np.ones(4,bool),0)
  self.assertEqual((m['tp'],m['fp'],m['fn'],m['tn']),(1,1,1,1));self.assertEqual(m['detection_delays_hours'],[1])
if __name__=='__main__':unittest.main(verbosity=2)
