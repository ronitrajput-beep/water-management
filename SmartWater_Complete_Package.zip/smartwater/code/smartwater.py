"""Reproducible, synthetic smart-water proof of concept. No field data."""
from pathlib import Path
import json, sqlite3
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parents[1]

def generate(seed=42):
    rng=np.random.default_rng(seed); n=28*24; t=np.arange(n); hour=t%24
    expected=20+6*np.sin(2*np.pi*(hour-6)/24)
    flow=expected+rng.normal(0,.65,n); pressure=40+rng.normal(0,.35,n)
    leak=np.zeros(n,dtype=bool)
    for start,end,amount in [(16*24,17*24,7),(19*24,21*24,4),(25*24,26*24,9)]:
        leak[start:end]=True; flow[start:end]+=amount; pressure[start:end]-=amount*.35
    # Legitimate high usage, bad telemetry, and a non-leak pressure change.
    flow[22*24:22*24+6]+=8
    flow[23*24:23*24+4]=np.nan
    pressure[24*24:24*24+5]-=3
    return t,flow,pressure,leak

def fit(flow,pressure,train_end=14*24):
    return (np.array([np.nanmedian(flow[h:train_end:24]) for h in range(24)]),float(np.nanmedian(pressure[:train_end])))

def detect(flow,pressure,profile,p0,mode='hybrid'):
    baseline=profile[np.arange(len(flow))%24]
    valid=np.isfinite(flow)&np.isfinite(pressure)
    candidate=valid & ((flow-baseline)>3)
    if mode=='hybrid': candidate &= ((p0-pressure)>.8)
    alert=np.zeros(len(flow),dtype=bool); run=0
    for i,flag in enumerate(candidate):
        run=run+1 if flag else 0
        alert[i]=run>=2
    return alert,valid,baseline

def metrics(truth,pred,valid,start=14*24):
    take=(np.arange(len(truth))>=start)&valid
    y=truth[take]; p=pred[take]
    tp=int(np.sum(y&p)); fp=int(np.sum(~y&p)); fn=int(np.sum(y&~p)); tn=int(np.sum(~y&~p))
    precision=tp/(tp+fp) if tp+fp else 0; recall=tp/(tp+fn) if tp+fn else 0
    events=[]; delays=[]
    starts=np.flatnonzero(truth & ~np.r_[False,truth[:-1]])
    for s in starts[starts>=start]:
        end=s
        while end<len(truth) and truth[end]: end+=1
        hits=np.flatnonzero(pred[s:end]); events.append(bool(len(hits)))
        if len(hits):delays.append(int(hits[0]))
    return dict(tp=tp,fp=fp,fn=fn,tn=tn,precision=precision,recall=recall,
                f1=2*precision*recall/(precision+recall) if precision+recall else 0,
                evaluated_samples=int(take.sum()),missing_samples=int((~valid[start:]).sum()),
                events_detected=sum(events),events_total=len(events),detection_delays_hours=delays)

def main():
    out=ROOT/'results'; out.mkdir(exist_ok=True); (ROOT/'figures').mkdir(exist_ok=True)
    t,f,p,y=generate(); prof,p0=fit(f,p)
    report={'data':'SYNTHETIC hourly toy data, seed 42; no hydraulic simulation or field collection',
            'training_samples':336,'test_samples':336,'flow_units':'litres/minute','pressure_units':'metres head','models':{}}
    alerts={}
    for mode in ['flow_only','hybrid']:
        a,v,b=detect(f,p,prof,p0,mode); alerts[mode]=a; report['models'][mode]=metrics(y,a,v)
    clean=(t>=336)&v&~y
    report['normal_period_mae_lpm']=float(np.mean(np.abs(f[clean]-b[clean])))
    report['normal_period_note']='Includes legitimate high-usage event; excludes true leaks and invalid readings.'
    report['thresholds']={'flow_excess_lpm':3,'pressure_drop_m':.8,'consecutive_readings':2}
    stress=[]
    for seed in range(10):
        st,sf,sp,sy=generate(seed); sb,s0=fit(sf,sp); sa,sv,_=detect(sf,sp,sb,s0)
        stress.append(metrics(sy,sa,sv))
    report['ten_seed_f1']={'min':min(x['f1'] for x in stress),'max':max(x['f1'] for x in stress),'mean':float(np.mean([x['f1'] for x in stress]))}
    np.savetxt(out/'telemetry.csv',np.column_stack([t,f,p,y,b,alerts['flow_only'],alerts['hybrid']]),delimiter=',',header='hour,flow_lpm,pressure_m,leak_truth,expected_flow_lpm,flow_only_alert,hybrid_alert',comments='')
    (out/'metrics.json').write_text(json.dumps(report,indent=2))
    db=sqlite3.connect(out/'water.db'); db.execute('CREATE TABLE IF NOT EXISTS readings(hour INTEGER PRIMARY KEY,flow REAL,pressure REAL,truth INTEGER,alert INTEGER)')
    db.executemany('INSERT OR REPLACE INTO readings VALUES(?,?,?,?,?)',[(int(i),float(f[i]) if np.isfinite(f[i]) else None,float(p[i]),int(y[i]),int(alerts['hybrid'][i])) for i in t]);db.commit();db.close()
    plt.rcParams.update({'font.size':10})
    fig,ax=plt.subplots(2,1,figsize=(10,5),sharex=True)
    ax[0].plot(t/24,f,label='Observed synthetic flow',lw=1);ax[0].plot(t/24,b,label='Training-only hourly median',lw=1);ax[0].set_ylabel('Flow (L/min)');ax[0].legend(fontsize=8)
    ax[1].plot(t/24,p,color='#127c8a',lw=1,label='Synthetic pressure');ax[1].scatter(t[alerts['hybrid']]/24,p[alerts['hybrid']],s=9,c='#d76139',label='Hybrid alerts');ax[1].set_ylabel('Head (m)');ax[1].set_xlabel('Synthetic elapsed day');ax[1].legend(fontsize=8)
    for a in ax:a.axvline(14,color='black',ls='--',lw=1);a.grid(alpha=.2)
    fig.tight_layout();fig.savefig(ROOT/'figures'/'results.png',dpi=180);plt.close(fig)
    labels=['Precision','Recall','F1'];fig,ax=plt.subplots(figsize=(8,3.4));x=np.arange(3)
    for j,m in enumerate(['flow_only','hybrid']):ax.bar(x+(j-.5)*.3,[report['models'][m][k] for k in ['precision','recall','f1']],.3,label=m.replace('_',' '))
    ax.set_xticks(x,labels);ax.set_ylim(0,1.12);ax.legend();ax.set_title('Synthetic demonstration only — seed 42');fig.tight_layout();fig.savefig(ROOT/'figures'/'comparison.png',dpi=180);plt.close(fig)
    (out/'dashboard.html').write_text('<!doctype html><html><meta charset="utf-8"><title>SmartWater — synthetic demonstration</title><style>body{font:18px system-ui;max-width:1050px;margin:40px auto;background:#eef5f7;color:#123448}pre{background:white;padding:24px;white-space:pre-wrap}img{width:100%}</style><h1>SmartWater</h1><p>Reproducible synthetic demonstration · 28 days · hourly samples · seed 42</p><img src="../figures/results.png"><img src="../figures/comparison.png"><h2>Evaluation record</h2><pre>'+json.dumps(report,indent=2)+'</pre><p>No live sensor connection, hydraulic validation, or field performance claim.</p></html>')
    print(json.dumps(report,indent=2))
if __name__=='__main__': main()
